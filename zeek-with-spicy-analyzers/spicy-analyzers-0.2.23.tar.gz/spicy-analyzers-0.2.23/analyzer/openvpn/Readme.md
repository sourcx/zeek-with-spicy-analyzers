# OpenVPN

This is a protocol analyzer that detects OpenVPN traffic.

Blogs and webinars detailing the development of this protocol analyzer:

- <https://zeek.org/2021/03/16/a-zeek-openvpn-protocol-analyzer/>
- <https://zeek.org/2021/04/08/a-zeek-openvpn-protocol-analyzer-in-spicy/>
- <https://event.webinarjam.com/replay/16/405xvaqawfzfqn>
  - Slides: <https://docs.google.com/presentation/d/1ftvMeQ-9hyeozTLXyO_CLVHDLGiwbJk9SqCp8laD1FM/edit?usp=sharing>
