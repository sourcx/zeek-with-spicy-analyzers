:tocdepth: 3

policy/frameworks/files/extract-all-files.zeek
==============================================

Extract all files to disk.

:Imports: :doc:`base/files/extract </scripts/base/files/extract/index>`

Summary
~~~~~~~

Detailed Interface
~~~~~~~~~~~~~~~~~~

