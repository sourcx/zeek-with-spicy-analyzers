:tocdepth: 3

policy/frameworks/intel/do_expire.zeek
======================================
.. zeek:namespace:: Intel

This script enables expiration for intelligence items.

:Namespace: Intel
:Imports: :doc:`base/frameworks/intel </scripts/base/frameworks/intel/index>`

Summary
~~~~~~~
Redefinitions
#############
============================================================================ =
:zeek:id:`Intel::item_expiration`: :zeek:type:`interval` :zeek:attr:`&redef` 
============================================================================ =


Detailed Interface
~~~~~~~~~~~~~~~~~~

