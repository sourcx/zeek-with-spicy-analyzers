:tocdepth: 3

policy/frameworks/intel/seen/file-names.zeek
============================================


:Imports: :doc:`base/frameworks/intel </scripts/base/frameworks/intel/index>`, :doc:`policy/frameworks/intel/seen/where-locations.zeek </scripts/policy/frameworks/intel/seen/where-locations.zeek>`

Summary
~~~~~~~

Detailed Interface
~~~~~~~~~~~~~~~~~~

