:tocdepth: 3

policy/tuning/defaults/warnings.zeek
====================================

This file is meant to print messages on stdout for settings that would be
good to set in most cases or other things that could be done to achieve 
better detection.

:Imports: :doc:`base/utils/site.zeek </scripts/base/utils/site.zeek>`

Summary
~~~~~~~

Detailed Interface
~~~~~~~~~~~~~~~~~~

