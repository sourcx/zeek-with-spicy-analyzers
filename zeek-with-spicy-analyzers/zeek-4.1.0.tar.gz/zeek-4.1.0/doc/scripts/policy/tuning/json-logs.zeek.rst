:tocdepth: 3

policy/tuning/json-logs.zeek
============================

Loading this script will cause all logs to be written
out as JSON by default.


Summary
~~~~~~~
Redefinitions
#############
==================================================================== =
:zeek:id:`LogAscii::use_json`: :zeek:type:`bool` :zeek:attr:`&redef` 
==================================================================== =


Detailed Interface
~~~~~~~~~~~~~~~~~~

