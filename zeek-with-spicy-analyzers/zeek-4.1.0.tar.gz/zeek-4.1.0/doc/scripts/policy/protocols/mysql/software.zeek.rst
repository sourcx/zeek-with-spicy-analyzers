:tocdepth: 3

policy/protocols/mysql/software.zeek
====================================
.. zeek:namespace:: MySQL

Software identification and extraction for MySQL traffic.

:Namespace: MySQL
:Imports: :doc:`base/frameworks/software </scripts/base/frameworks/software/index>`

Summary
~~~~~~~
Redefinitions
#############
============================================== =========================================================
:zeek:type:`Software::Type`: :zeek:type:`enum` 
                                               
                                               * :zeek:enum:`MySQL::SERVER`:
                                                 Identifier for MySQL servers in the software framework.
============================================== =========================================================


Detailed Interface
~~~~~~~~~~~~~~~~~~

