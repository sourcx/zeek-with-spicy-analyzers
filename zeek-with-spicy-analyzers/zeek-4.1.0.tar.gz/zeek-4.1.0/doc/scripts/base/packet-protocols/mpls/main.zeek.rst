:tocdepth: 3

base/packet-protocols/mpls/main.zeek
====================================
.. zeek:namespace:: PacketAnalyzer::MPLS


:Namespace: PacketAnalyzer::MPLS

Summary
~~~~~~~
Redefinable Options
###################
======================================================================================================= ================
:zeek:id:`PacketAnalyzer::MPLS::default_analyzer`: :zeek:type:`PacketAnalyzer::Tag` :zeek:attr:`&redef` Default analyzer
======================================================================================================= ================


Detailed Interface
~~~~~~~~~~~~~~~~~~
Redefinable Options
###################
.. zeek:id:: PacketAnalyzer::MPLS::default_analyzer
   :source-code: base/packet-protocols/mpls/main.zeek 5 5

   :Type: :zeek:type:`PacketAnalyzer::Tag`
   :Attributes: :zeek:attr:`&redef`
   :Default: ``PacketAnalyzer::ANALYZER_IP``

   Default analyzer


