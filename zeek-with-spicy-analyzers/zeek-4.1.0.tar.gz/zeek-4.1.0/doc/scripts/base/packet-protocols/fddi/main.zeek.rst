:tocdepth: 3

base/packet-protocols/fddi/main.zeek
====================================
.. zeek:namespace:: PacketAnalyzer::FDDI


:Namespace: PacketAnalyzer::FDDI

Summary
~~~~~~~
Redefinable Options
###################
======================================================================================================= ================
:zeek:id:`PacketAnalyzer::FDDI::default_analyzer`: :zeek:type:`PacketAnalyzer::Tag` :zeek:attr:`&redef` Default analyzer
======================================================================================================= ================


Detailed Interface
~~~~~~~~~~~~~~~~~~
Redefinable Options
###################
.. zeek:id:: PacketAnalyzer::FDDI::default_analyzer
   :source-code: base/packet-protocols/fddi/main.zeek 5 5

   :Type: :zeek:type:`PacketAnalyzer::Tag`
   :Attributes: :zeek:attr:`&redef`
   :Default: ``PacketAnalyzer::ANALYZER_IP``

   Default analyzer


