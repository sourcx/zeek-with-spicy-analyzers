:tocdepth: 3

base/bif/plugins/Zeek_ConfigReader.config.bif.zeek
==================================================
.. zeek:namespace:: GLOBAL
.. zeek:namespace:: InputConfig


:Namespaces: GLOBAL, InputConfig

Summary
~~~~~~~

Detailed Interface
~~~~~~~~~~~~~~~~~~

