:tocdepth: 3

base/bif/plugins/Zeek_Modbus.events.bif.zeek
============================================
.. zeek:namespace:: GLOBAL


:Namespace: GLOBAL

Summary
~~~~~~~
Events
######
============================================================================ ======================================================================
:zeek:id:`modbus_exception`: :zeek:type:`event`                              Generated for any Modbus exception message.
:zeek:id:`modbus_mask_write_register_request`: :zeek:type:`event`            Generated for a Modbus mask write register request.
:zeek:id:`modbus_mask_write_register_response`: :zeek:type:`event`           Generated for a Modbus mask write register request.
:zeek:id:`modbus_message`: :zeek:type:`event`                                Generated for any Modbus message regardless if the particular function
                                                                             is further supported or not.
:zeek:id:`modbus_read_coils_request`: :zeek:type:`event`                     Generated for a Modbus read coils request.
:zeek:id:`modbus_read_coils_response`: :zeek:type:`event`                    Generated for a Modbus read coils response.
:zeek:id:`modbus_read_discrete_inputs_request`: :zeek:type:`event`           Generated for a Modbus read discrete inputs request.
:zeek:id:`modbus_read_discrete_inputs_response`: :zeek:type:`event`          Generated for a Modbus read discrete inputs response.
:zeek:id:`modbus_read_fifo_queue_request`: :zeek:type:`event`                Generated for a Modbus read FIFO queue request.
:zeek:id:`modbus_read_fifo_queue_response`: :zeek:type:`event`               Generated for a Modbus read FIFO queue response.
:zeek:id:`modbus_read_file_record_request`: :zeek:type:`event`               Generated for a Modbus read file record request.
:zeek:id:`modbus_read_file_record_response`: :zeek:type:`event`              Generated for a Modbus read file record response.
:zeek:id:`modbus_read_holding_registers_request`: :zeek:type:`event`         Generated for a Modbus read holding registers request.
:zeek:id:`modbus_read_holding_registers_response`: :zeek:type:`event`        Generated for a Modbus read holding registers response.
:zeek:id:`modbus_read_input_registers_request`: :zeek:type:`event`           Generated for a Modbus read input registers request.
:zeek:id:`modbus_read_input_registers_response`: :zeek:type:`event`          Generated for a Modbus read input registers response.
:zeek:id:`modbus_read_write_multiple_registers_request`: :zeek:type:`event`  Generated for a Modbus read/write multiple registers request.
:zeek:id:`modbus_read_write_multiple_registers_response`: :zeek:type:`event` Generated for a Modbus read/write multiple registers response.
:zeek:id:`modbus_write_file_record_request`: :zeek:type:`event`              Generated for a Modbus write file record request.
:zeek:id:`modbus_write_file_record_response`: :zeek:type:`event`             Generated for a Modbus write file record response.
:zeek:id:`modbus_write_multiple_coils_request`: :zeek:type:`event`           Generated for a Modbus write multiple coils request.
:zeek:id:`modbus_write_multiple_coils_response`: :zeek:type:`event`          Generated for a Modbus write multiple coils response.
:zeek:id:`modbus_write_multiple_registers_request`: :zeek:type:`event`       Generated for a Modbus write multiple registers request.
:zeek:id:`modbus_write_multiple_registers_response`: :zeek:type:`event`      Generated for a Modbus write multiple registers response.
:zeek:id:`modbus_write_single_coil_request`: :zeek:type:`event`              Generated for a Modbus write single coil request.
:zeek:id:`modbus_write_single_coil_response`: :zeek:type:`event`             Generated for a Modbus write single coil response.
:zeek:id:`modbus_write_single_register_request`: :zeek:type:`event`          Generated for a Modbus write single register request.
:zeek:id:`modbus_write_single_register_response`: :zeek:type:`event`         Generated for a Modbus write single register response.
============================================================================ ======================================================================


Detailed Interface
~~~~~~~~~~~~~~~~~~
Events
######
.. zeek:id:: modbus_exception
   :source-code: base/bif/plugins/Zeek_Modbus.events.bif.zeek 22 22

   :Type: :zeek:type:`event` (c: :zeek:type:`connection`, headers: :zeek:type:`ModbusHeaders`, code: :zeek:type:`count`)

   Generated for any Modbus exception message.
   

   :c: The connection.
   

   :headers: The headers for the modbus function.
   

   :code: The exception code.

.. zeek:id:: modbus_mask_write_register_request
   :source-code: base/bif/plugins/Zeek_Modbus.events.bif.zeek 264 264

   :Type: :zeek:type:`event` (c: :zeek:type:`connection`, headers: :zeek:type:`ModbusHeaders`, address: :zeek:type:`count`, and_mask: :zeek:type:`count`, or_mask: :zeek:type:`count`)

   Generated for a Modbus mask write register request.
   

   :c: The connection.
   

   :headers: The headers for the modbus function.
   

   :address: The memory address of the register where the masks should be applied.
   

   :and_mask: The value of the logical AND mask to apply to the register.
   

   :or_mask: The value of the logical OR mask to apply to the register.

.. zeek:id:: modbus_mask_write_register_response
   :source-code: base/bif/plugins/Zeek_Modbus.events.bif.zeek 278 278

   :Type: :zeek:type:`event` (c: :zeek:type:`connection`, headers: :zeek:type:`ModbusHeaders`, address: :zeek:type:`count`, and_mask: :zeek:type:`count`, or_mask: :zeek:type:`count`)

   Generated for a Modbus mask write register request.
   

   :c: The connection.
   

   :headers: The headers for the modbus function.
   

   :address: The memory address of the register where the masks were applied.
   

   :and_mask: The value of the logical AND mask applied register.
   

   :or_mask: The value of the logical OR mask applied to the register.

.. zeek:id:: modbus_message
   :source-code: base/bif/plugins/Zeek_Modbus.events.bif.zeek 12 12

   :Type: :zeek:type:`event` (c: :zeek:type:`connection`, headers: :zeek:type:`ModbusHeaders`, is_orig: :zeek:type:`bool`)

   Generated for any Modbus message regardless if the particular function
   is further supported or not.
   

   :c: The connection.
   

   :headers: The headers for the modbus function.
   

   :is_orig: True if the event is raised for the originator side.

.. zeek:id:: modbus_read_coils_request
   :source-code: base/bif/plugins/Zeek_Modbus.events.bif.zeek 34 34

   :Type: :zeek:type:`event` (c: :zeek:type:`connection`, headers: :zeek:type:`ModbusHeaders`, start_address: :zeek:type:`count`, quantity: :zeek:type:`count`)

   Generated for a Modbus read coils request.
   

   :c: The connection.
   

   :headers: The headers for the modbus function.
   

   :start_address: The memory address of the first coil to be read.
   

   :quantity: The number of coils to be read.

.. zeek:id:: modbus_read_coils_response
   :source-code: base/bif/plugins/Zeek_Modbus.events.bif.zeek 44 44

   :Type: :zeek:type:`event` (c: :zeek:type:`connection`, headers: :zeek:type:`ModbusHeaders`, coils: :zeek:type:`ModbusCoils`)

   Generated for a Modbus read coils response.
   

   :c: The connection.
   

   :headers: The headers for the modbus function.
   

   :coils: The coil values returned from the device.

.. zeek:id:: modbus_read_discrete_inputs_request
   :source-code: base/bif/plugins/Zeek_Modbus.events.bif.zeek 56 56

   :Type: :zeek:type:`event` (c: :zeek:type:`connection`, headers: :zeek:type:`ModbusHeaders`, start_address: :zeek:type:`count`, quantity: :zeek:type:`count`)

   Generated for a Modbus read discrete inputs request.
   

   :c: The connection.
   

   :headers: The headers for the modbus function.
   

   :start_address: The memory address of the first coil to be read.
   

   :quantity: The number of coils to be read.

.. zeek:id:: modbus_read_discrete_inputs_response
   :source-code: base/bif/plugins/Zeek_Modbus.events.bif.zeek 66 66

   :Type: :zeek:type:`event` (c: :zeek:type:`connection`, headers: :zeek:type:`ModbusHeaders`, coils: :zeek:type:`ModbusCoils`)

   Generated for a Modbus read discrete inputs response.
   

   :c: The connection.
   

   :headers: The headers for the modbus function.
   

   :coils: The coil values returned from the device.

.. zeek:id:: modbus_read_fifo_queue_request
   :source-code: base/bif/plugins/Zeek_Modbus.events.bif.zeek 315 315

   :Type: :zeek:type:`event` (c: :zeek:type:`connection`, headers: :zeek:type:`ModbusHeaders`, start_address: :zeek:type:`count`)

   Generated for a Modbus read FIFO queue request.
   

   :c: The connection.
   

   :headers: The headers for the modbus function.
   

   :start_address: The address of the FIFO queue to read.

.. zeek:id:: modbus_read_fifo_queue_response
   :source-code: base/bif/plugins/Zeek_Modbus.events.bif.zeek 325 325

   :Type: :zeek:type:`event` (c: :zeek:type:`connection`, headers: :zeek:type:`ModbusHeaders`, fifos: :zeek:type:`ModbusRegisters`)

   Generated for a Modbus read FIFO queue response.
   

   :c: The connection.
   

   :headers: The headers for the modbus function.
   

   :fifos: The register values read from the FIFO queue on the device.

.. zeek:id:: modbus_read_file_record_request
   :source-code: base/bif/plugins/Zeek_Modbus.events.bif.zeek 217 217

   :Type: :zeek:type:`event` (c: :zeek:type:`connection`, headers: :zeek:type:`ModbusHeaders`)

   Generated for a Modbus read file record request.
   

   :c: The connection.
   

   :headers: The headers for the modbus function.
   
   .. note: This event is incomplete.  The information from the data structure
            is not yet passed through to the event.

.. zeek:id:: modbus_read_file_record_response
   :source-code: base/bif/plugins/Zeek_Modbus.events.bif.zeek 228 228

   :Type: :zeek:type:`event` (c: :zeek:type:`connection`, headers: :zeek:type:`ModbusHeaders`)

   Generated for a Modbus read file record response.
   

   :c: The connection.
   

   :headers: The headers for the modbus function.
   
   .. note: This event is incomplete.  The information from the data structure
            is not yet passed through to the event.

.. zeek:id:: modbus_read_holding_registers_request
   :source-code: policy/protocols/modbus/track-memmap.zeek 62 65

   :Type: :zeek:type:`event` (c: :zeek:type:`connection`, headers: :zeek:type:`ModbusHeaders`, start_address: :zeek:type:`count`, quantity: :zeek:type:`count`)

   Generated for a Modbus read holding registers request.
   

   :c: The connection.
   

   :headers: The headers for the modbus function.
   

   :start_address: The memory address of the first register to be read.
   

   :quantity: The number of registers to be read.

.. zeek:id:: modbus_read_holding_registers_response
   :source-code: policy/protocols/modbus/track-memmap.zeek 67 102

   :Type: :zeek:type:`event` (c: :zeek:type:`connection`, headers: :zeek:type:`ModbusHeaders`, registers: :zeek:type:`ModbusRegisters`)

   Generated for a Modbus read holding registers response.
   

   :c: The connection.
   

   :headers: The headers for the modbus function.
   

   :registers: The register values returned from the device.

.. zeek:id:: modbus_read_input_registers_request
   :source-code: base/bif/plugins/Zeek_Modbus.events.bif.zeek 100 100

   :Type: :zeek:type:`event` (c: :zeek:type:`connection`, headers: :zeek:type:`ModbusHeaders`, start_address: :zeek:type:`count`, quantity: :zeek:type:`count`)

   Generated for a Modbus read input registers request.
   

   :c: The connection.
   

   :headers: The headers for the modbus function.
   

   :start_address: The memory address of the first register to be read.
   

   :quantity: The number of registers to be read.

.. zeek:id:: modbus_read_input_registers_response
   :source-code: base/bif/plugins/Zeek_Modbus.events.bif.zeek 110 110

   :Type: :zeek:type:`event` (c: :zeek:type:`connection`, headers: :zeek:type:`ModbusHeaders`, registers: :zeek:type:`ModbusRegisters`)

   Generated for a Modbus read input registers response.
   

   :c: The connection.
   

   :headers: The headers for the modbus function.
   

   :registers: The register values returned from the device.

.. zeek:id:: modbus_read_write_multiple_registers_request
   :source-code: base/bif/plugins/Zeek_Modbus.events.bif.zeek 294 294

   :Type: :zeek:type:`event` (c: :zeek:type:`connection`, headers: :zeek:type:`ModbusHeaders`, read_start_address: :zeek:type:`count`, read_quantity: :zeek:type:`count`, write_start_address: :zeek:type:`count`, write_registers: :zeek:type:`ModbusRegisters`)

   Generated for a Modbus read/write multiple registers request.
   

   :c: The connection.
   

   :headers: The headers for the modbus function.
   

   :read_start_address: The memory address of the first register to be read.
   

   :read_quantity: The number of registers to read.
   

   :write_start_address: The memory address of the first register to be written.
   

   :write_registers: The values to be written to the registers.

.. zeek:id:: modbus_read_write_multiple_registers_response
   :source-code: base/bif/plugins/Zeek_Modbus.events.bif.zeek 305 305

   :Type: :zeek:type:`event` (c: :zeek:type:`connection`, headers: :zeek:type:`ModbusHeaders`, written_registers: :zeek:type:`ModbusRegisters`)

   Generated for a Modbus read/write multiple registers response.
   

   :c: The connection.
   

   :headers: The headers for the modbus function.
   

   :written_registers: The register values read from the registers specified in
                      the request.

.. zeek:id:: modbus_write_file_record_request
   :source-code: base/bif/plugins/Zeek_Modbus.events.bif.zeek 239 239

   :Type: :zeek:type:`event` (c: :zeek:type:`connection`, headers: :zeek:type:`ModbusHeaders`)

   Generated for a Modbus write file record request.
   

   :c: The connection.
   

   :headers: The headers for the modbus function.
   
   .. note: This event is incomplete.  The information from the data structure
            is not yet passed through to the event.

.. zeek:id:: modbus_write_file_record_response
   :source-code: base/bif/plugins/Zeek_Modbus.events.bif.zeek 250 250

   :Type: :zeek:type:`event` (c: :zeek:type:`connection`, headers: :zeek:type:`ModbusHeaders`)

   Generated for a Modbus write file record response.
   

   :c: The connection.
   

   :headers: The headers for the modbus function.
   
   .. note: This event is incomplete.  The information from the data structure
            is not yet passed through to the event.

.. zeek:id:: modbus_write_multiple_coils_request
   :source-code: base/bif/plugins/Zeek_Modbus.events.bif.zeek 170 170

   :Type: :zeek:type:`event` (c: :zeek:type:`connection`, headers: :zeek:type:`ModbusHeaders`, start_address: :zeek:type:`count`, coils: :zeek:type:`ModbusCoils`)

   Generated for a Modbus write multiple coils request.
   

   :c: The connection.
   

   :headers: The headers for the modbus function.
   

   :start_address: The memory address of the first coil to be written.
   

   :coils: The values to be written to the coils.

.. zeek:id:: modbus_write_multiple_coils_response
   :source-code: base/bif/plugins/Zeek_Modbus.events.bif.zeek 182 182

   :Type: :zeek:type:`event` (c: :zeek:type:`connection`, headers: :zeek:type:`ModbusHeaders`, start_address: :zeek:type:`count`, quantity: :zeek:type:`count`)

   Generated for a Modbus write multiple coils response.
   

   :c: The connection.
   

   :headers: The headers for the modbus function.
   

   :start_address: The memory address of the first coil that was written.
   

   :quantity: The quantity of coils that were written.

.. zeek:id:: modbus_write_multiple_registers_request
   :source-code: base/bif/plugins/Zeek_Modbus.events.bif.zeek 194 194

   :Type: :zeek:type:`event` (c: :zeek:type:`connection`, headers: :zeek:type:`ModbusHeaders`, start_address: :zeek:type:`count`, registers: :zeek:type:`ModbusRegisters`)

   Generated for a Modbus write multiple registers request.
   

   :c: The connection.
   

   :headers: The headers for the modbus function.
   

   :start_address: The memory address of the first register to be written.
   

   :registers: The values to be written to the registers.

.. zeek:id:: modbus_write_multiple_registers_response
   :source-code: base/bif/plugins/Zeek_Modbus.events.bif.zeek 206 206

   :Type: :zeek:type:`event` (c: :zeek:type:`connection`, headers: :zeek:type:`ModbusHeaders`, start_address: :zeek:type:`count`, quantity: :zeek:type:`count`)

   Generated for a Modbus write multiple registers response.
   

   :c: The connection.
   

   :headers: The headers for the modbus function.
   

   :start_address: The memory address of the first register that was written.
   

   :quantity: The quantity of registers that were written.

.. zeek:id:: modbus_write_single_coil_request
   :source-code: base/bif/plugins/Zeek_Modbus.events.bif.zeek 122 122

   :Type: :zeek:type:`event` (c: :zeek:type:`connection`, headers: :zeek:type:`ModbusHeaders`, address: :zeek:type:`count`, value: :zeek:type:`bool`)

   Generated for a Modbus write single coil request.
   

   :c: The connection.
   

   :headers: The headers for the modbus function.
   

   :address: The memory address of the coil to be written.
   

   :value: The value to be written to the coil.

.. zeek:id:: modbus_write_single_coil_response
   :source-code: base/bif/plugins/Zeek_Modbus.events.bif.zeek 134 134

   :Type: :zeek:type:`event` (c: :zeek:type:`connection`, headers: :zeek:type:`ModbusHeaders`, address: :zeek:type:`count`, value: :zeek:type:`bool`)

   Generated for a Modbus write single coil response.
   

   :c: The connection.
   

   :headers: The headers for the modbus function.
   

   :address: The memory address of the coil that was written.
   

   :value: The value that was written to the coil.

.. zeek:id:: modbus_write_single_register_request
   :source-code: base/bif/plugins/Zeek_Modbus.events.bif.zeek 146 146

   :Type: :zeek:type:`event` (c: :zeek:type:`connection`, headers: :zeek:type:`ModbusHeaders`, address: :zeek:type:`count`, value: :zeek:type:`count`)

   Generated for a Modbus write single register request.
   

   :c: The connection.
   

   :headers: The headers for the modbus function.
   

   :address: The memory address of the register to be written.
   

   :value: The value to be written to the register.

.. zeek:id:: modbus_write_single_register_response
   :source-code: base/bif/plugins/Zeek_Modbus.events.bif.zeek 158 158

   :Type: :zeek:type:`event` (c: :zeek:type:`connection`, headers: :zeek:type:`ModbusHeaders`, address: :zeek:type:`count`, value: :zeek:type:`count`)

   Generated for a Modbus write single register response.
   

   :c: The connection.
   

   :headers: The headers for the modbus function.
   

   :address: The memory address of the register that was written.
   

   :value: The value that was written to the register.


