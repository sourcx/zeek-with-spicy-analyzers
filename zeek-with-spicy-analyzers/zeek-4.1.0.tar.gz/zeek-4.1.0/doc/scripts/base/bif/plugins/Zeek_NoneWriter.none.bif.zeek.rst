:tocdepth: 3

base/bif/plugins/Zeek_NoneWriter.none.bif.zeek
==============================================
.. zeek:namespace:: GLOBAL
.. zeek:namespace:: LogNone


:Namespaces: GLOBAL, LogNone

Summary
~~~~~~~

Detailed Interface
~~~~~~~~~~~~~~~~~~

