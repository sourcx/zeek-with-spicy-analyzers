:tocdepth: 3

base/bif/plugins/Zeek_FileExtract.functions.bif.zeek
====================================================
.. zeek:namespace:: FileExtract
.. zeek:namespace:: GLOBAL

Internal functions used by the extraction file analyzer.

:Namespaces: FileExtract, GLOBAL

Summary
~~~~~~~
Functions
#########
========================================================== ===================================
:zeek:id:`FileExtract::__set_limit`: :zeek:type:`function` :zeek:see:`FileExtract::set_limit`.
========================================================== ===================================


Detailed Interface
~~~~~~~~~~~~~~~~~~
Functions
#########
.. zeek:id:: FileExtract::__set_limit
   :source-code: base/bif/plugins/Zeek_FileExtract.functions.bif.zeek 12 12

   :Type: :zeek:type:`function` (file_id: :zeek:type:`string`, args: :zeek:type:`any`, n: :zeek:type:`count`) : :zeek:type:`bool`

   :zeek:see:`FileExtract::set_limit`.


