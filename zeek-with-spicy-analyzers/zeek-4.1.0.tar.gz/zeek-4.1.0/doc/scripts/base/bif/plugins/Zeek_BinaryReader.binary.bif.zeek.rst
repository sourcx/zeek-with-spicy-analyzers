:tocdepth: 3

base/bif/plugins/Zeek_BinaryReader.binary.bif.zeek
==================================================
.. zeek:namespace:: GLOBAL
.. zeek:namespace:: InputBinary


:Namespaces: GLOBAL, InputBinary

Summary
~~~~~~~

Detailed Interface
~~~~~~~~~~~~~~~~~~

