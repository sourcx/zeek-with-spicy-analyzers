:tocdepth: 3

base/bif/plugins/Zeek_SMB.types.bif.zeek
========================================
.. zeek:namespace:: GLOBAL


:Namespace: GLOBAL

Summary
~~~~~~~

Detailed Interface
~~~~~~~~~~~~~~~~~~

