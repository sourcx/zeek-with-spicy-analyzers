:tocdepth: 3

base/bif/plugins/Zeek_BenchmarkReader.benchmark.bif.zeek
========================================================
.. zeek:namespace:: GLOBAL
.. zeek:namespace:: InputBenchmark


:Namespaces: GLOBAL, InputBenchmark

Summary
~~~~~~~

Detailed Interface
~~~~~~~~~~~~~~~~~~

