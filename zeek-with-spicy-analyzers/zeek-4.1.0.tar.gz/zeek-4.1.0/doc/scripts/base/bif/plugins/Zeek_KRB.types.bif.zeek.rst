:tocdepth: 3

base/bif/plugins/Zeek_KRB.types.bif.zeek
========================================
.. zeek:namespace:: GLOBAL
.. zeek:namespace:: KRB


:Namespaces: GLOBAL, KRB

Summary
~~~~~~~

Detailed Interface
~~~~~~~~~~~~~~~~~~

