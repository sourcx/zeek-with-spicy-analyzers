:tocdepth: 3

base/bif/plugins/Zeek_AsciiReader.ascii.bif.zeek
================================================
.. zeek:namespace:: GLOBAL
.. zeek:namespace:: InputAscii


:Namespaces: GLOBAL, InputAscii

Summary
~~~~~~~

Detailed Interface
~~~~~~~~~~~~~~~~~~

