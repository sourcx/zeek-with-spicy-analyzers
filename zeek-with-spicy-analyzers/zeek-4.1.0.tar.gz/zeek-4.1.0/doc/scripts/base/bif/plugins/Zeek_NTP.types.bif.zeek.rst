:tocdepth: 3

base/bif/plugins/Zeek_NTP.types.bif.zeek
========================================
.. zeek:namespace:: GLOBAL
.. zeek:namespace:: NTP


:Namespaces: GLOBAL, NTP

Summary
~~~~~~~

Detailed Interface
~~~~~~~~~~~~~~~~~~

