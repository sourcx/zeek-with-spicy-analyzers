:tocdepth: 3

base/bif/const.bif.zeek
=======================
.. zeek:namespace:: GLOBAL

Declaration of various scripting-layer constants that the Zeek core uses
internally.  Documentation and default values for the scripting-layer
variables themselves are found in :doc:`/scripts/base/init-bare.zeek`.

:Namespace: GLOBAL

Summary
~~~~~~~

Detailed Interface
~~~~~~~~~~~~~~~~~~

