// Copyright (c) 2020-2021 by the Zeek Project. See LICENSE for details.

/**
 * This header defines functions that are made available to Spicy grammars
 * inside the `spicy::*` namespace.
 */

#pragma once
