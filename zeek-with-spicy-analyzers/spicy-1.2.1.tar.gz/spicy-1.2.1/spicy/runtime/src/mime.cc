// Copyright (c) 2020-2021 by the Zeek Project. See LICENSE for details.

#include <spicy/rt/mime.h>

using namespace spicy::rt;

HILTI_EXCEPTION_IMPL(InvalidMIMEType)
