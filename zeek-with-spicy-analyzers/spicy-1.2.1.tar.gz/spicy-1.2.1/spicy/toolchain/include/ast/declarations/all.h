// Copyright (c) 2020-2021 by the Zeek Project. See LICENSE for details.

#pragma once

#include <spicy/ast/declarations/unit-hook.h>
