// Copyright (c) 2020-2021 by the Zeek Project. See LICENSE for details.

#include <hilti/ast/type.h>
#include <hilti/ast/types/id.h>

using namespace hilti;
